﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleNote
{
    class Cons
    {
        public static int DayOfWeek = 7;
        public static int DayOfColumn = 6;

        public static int dateButtonWidth = 96;
        public static int dateButtonHeight = 35;

        public static int margin = 6;
        public static int notifyTime = 3;
        public static int notifyTimeOut = 10000;
    }
}
